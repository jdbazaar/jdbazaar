A Pen created at CodePen.io. You can find this one at https://codepen.io/joe-watkins/pen/wBaOMq.

 Angular UI Google maps - https://angular-ui.github.io/angular-google-maps